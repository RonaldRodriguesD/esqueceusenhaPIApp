import * as React from 'react';
import { Text, View, StyleSheet, Image, ImageBackground, TextInput, TouchableHighlight } from 'react-native';
import Constants from 'expo-constants';
import Styles from './components/Styles'



export default function App() {
  return (
    <ImageBackground
      source={require('./assets/BoloseDocesFundo.jpg')}
      style={Styles.fundo}
    >
      <Image 
        source={require('./assets/CasaBolosLogo.png')}
        style={Styles.logo}
      />
      <View style={Styles.main}>
        <Text style={Styles.tituloMain}>Esqueceu sua senha?</Text>
        <Text style={Styles.textoMain}>Não se preocupe! Acontece. Por favor, insira o número de telefone associado a sua conta. </Text>
        <Text style={Styles.textoInput}>Telefone</Text>
        <TextInput style={Styles.inputNumero} />
        <TouchableHighlight
          activeOpacity = {0.1}
          underlayColor= '#f2adb9'
          onPress = {()=>{alert('Enviando...')}}
          style={Styles.buttonSenha}
        >
          <Text style={Styles.textoButton}>Enviar</Text>
        </TouchableHighlight>
      </View>
    </ImageBackground>
  );
}


